<template>
    
    <div class="container-fluid">



    </div>


</template>

<script>
export default {
    setup() {
        
    },
}
</script>

<style scoped>


</style>